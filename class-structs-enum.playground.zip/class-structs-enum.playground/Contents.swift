import UIKit
//1
class Student{
    var firstName: String = ""
    var lastName: String = ""
    var age: Int = 0
    var grade: Int = 0
    var department: Department
    init(firstName: String, lastName: String, age: Int, grade: Int, department: Department){
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
        self.grade = grade
        self.department = Department.ComputerScience
    }
    func getfullname(){
       print("\(firstName)\(lastName)\(department)")
    }
}
var sara = Student(firstName: "sara", lastName: "ali", age: 27, grade: 90, department: .ComputerScience)

sara.getfullname()

struct point{
    var x: Int
    var y: Int
    func sum(){
        print(x+y)
    }
}
var p = point(x: 4, y: 4)
print(p.sum())

//2
enum Department{
    case ComputerScience , Math , English , physics 
}

//3
struct Rectangle{
    var width : Int
    var height : Int
}
class Size{
    var width : Int = 0
    var height : Int = 0
}
var re = Rectangle(width: 4, height: 5)
var si = Size()
