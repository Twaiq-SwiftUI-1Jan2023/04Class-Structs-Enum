import  UIKit

//Q1 Class
class Student {
    var fristname :String = ""
    var lastname :String = ""
    var age :Int = 0
    var grade :Int = 0
    var department : Department
    init (fristname :String , lastname :String ,age :Int ,grade :Int, department :Department){
        self.fristname = fristname
        self.lastname = lastname
        self.age = age
        self.grade = grade
        self.department = Department.Math
    }
    func getfulname (){
        print("\(fristname) \(lastname)\(department)")
    }
}
var h = Student(fristname: "HATOUN", lastname: "ALI", age: 23, grade: 89, department:.Math)
h.getfulname ()

//struct
struct Point {
    var x :Int
    var y :Int
}
var B = Point(x: 55, y: 7)
print(B.x)
print(B.y)
//------------------------------------------------------
//Q2 Enum
enum Department {
  case  ComputerScience
  case   Math
  case   English
  case  Physics
}
//-------------------------------------------------------
//Q3 Comparison
struct Rectangle {
    var width :Int
    var height :Int
}
class Size {
    var width :Int = 0
    var height :Int = 0
   
}
var R = Rectangle(width: 5, height: 5)
var S = Size()


/*Compare the ihnstances and find the difference between structs and class in terms of how they are created and stored in memory. ?
 class -> refrence type , يمكن ان تستعمل Inheritence , نستطيع تغيير properties الخاصة بها من داخل methods
 struct -> value type ,لا يمكن استخدام الورثه فيه ، لايمكن ان نستعمل Inheritence */


